<?php
include "database.php";
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Livraria</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
            text-align: center;
        }
        .box {
            background-color: #ffffff;
            border: 1px solid #cccccc;
            width: 380px;
            margin: 0 auto;
            padding: 15px;
        }
        h2 {
            margin-top: 0;
            color: #444;
        }
        input {
            width: 95%;
            padding: 8px;
            margin: 5px 0;
            border: 1px solid #bbbbbb;
            border-radius: 4px;
        }
        button {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border: none;
            background-color: #5C6AC4;
            color: #ffffff;
            border-radius: 4px;
            cursor: pointer;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
            font-size: 13px;
        }
        th, td {
            border: 1px solid #dddddd;
            padding: 4px;
            text-align: left;
        }
        a {
            color: #c00000;
            text-decoration: none;
        }
        .subtitulo {
            margin-top: 12px;
            font-size: 13px;
            font-weight: bold;
            text-align: left;
        }
    </style>
</head>
<body>

<div class="box">
    <h2>Livraria</h2>

    <form action="add_book.php" method="POST">
        <input type="text"   name="titulo" placeholder="Título do livro" required>
        <input type="text"   name="autor"  placeholder="Autor" required>
        <input type="number" name="ano"    placeholder="Ano" required>
        <button type="submit">Adicionar livro</button>
    </form>

    <table>
        <tr>
            <th>Nº</th>
            <th>ID (banco)</th>
            <th>Título</th>
            <th>Autor</th>
            <th>Ano</th>
            <th></th>
        </tr>
        <?php
        $sql = "SELECT * FROM livros ORDER BY id ASC";
        $res = $conn->query($sql);

        $n = 1; 

        if ($res && $res->num_rows > 0) {
            while ($l = $res->fetch_assoc()) {
                echo "<tr>";
                echo "<td>".$n."</td>";                
                echo "<td>".$l['id']."</td>";         
                echo "<td>".$l['titulo']."</td>";
                echo "<td>".$l['autor']."</td>";
                echo "<td>".$l['ano']."</td>";
                echo "<td><a href='delete_book.php?id=".$l['id']."'>Excluir</a></td>";
                echo "</tr>";
                $n++;
            }
        }
        ?>
    </table>

    <div class="subtitulo">Excluir livro pelo ID do banco:</div>
    <form action="delete_book.php" method="GET">
        <input type="number" name="id" placeholder="Digite o ID do livro" required>
        <button type="submit">Excluir por ID</button>
    </form>
</div>

</body>
</html>