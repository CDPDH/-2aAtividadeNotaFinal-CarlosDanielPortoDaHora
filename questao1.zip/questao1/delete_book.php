<?php
include "database.php";

if (isset($_GET['id'])) {
    $id  = $_GET['id'];
    $sql = "DELETE FROM livros WHERE id = $id";
    $conn->query($sql);
}

header("Location: index.php");
exit;
?>