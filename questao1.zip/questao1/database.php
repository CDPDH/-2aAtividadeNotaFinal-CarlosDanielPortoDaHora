<?php
$server = "localhost";
$user   = "root";
$pass   = "";

$conn = new mysqli($server, $user, $pass);

if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}

$dbName = "livraria_db";
$sqlCreateDb = "CREATE DATABASE IF NOT EXISTS $dbName";

if (!$conn->query($sqlCreateDb)) {
    die("Erro ao criar banco: " . $conn->error);
}

$conn->select_db($dbName);

$sqlCreateTable = "CREATE TABLE IF NOT EXISTS livros (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(200) NOT NULL,
    autor VARCHAR(200) NOT NULL,
    ano INT
)";

if (!$conn->query($sqlCreateTable)) {
    die("Erro ao criar tabela livros: " . $conn->error);
}
?>
