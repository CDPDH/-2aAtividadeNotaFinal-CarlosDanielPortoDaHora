<?php
$server = "localhost";
$user   = "root";
$pass   = "";

$conn = new mysqli($server, $user, $pass);

if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}

$dbName = "tarefas_db";
$sqlBanco = "CREATE DATABASE IF NOT EXISTS $dbName";

if (!$conn->query($sqlBanco)) {
    die("Erro ao criar banco: " . $conn->error);
}

$conn->select_db($dbName);

$sqlTabela = "CREATE TABLE IF NOT EXISTS tarefas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    descricao VARCHAR(255) NOT NULL,
    prazo DATE,
    concluida TINYINT(1) DEFAULT 0
)";

if (!$conn->query($sqlTabela)) {
    die("Erro ao criar tabela tarefas: " . $conn->error);
}
?>
