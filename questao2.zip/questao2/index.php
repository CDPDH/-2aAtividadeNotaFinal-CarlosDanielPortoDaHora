<?php
include "database.php";
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Lista de Tarefas</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
            text-align: center;
        }
        .box {
            background-color: #ffffff;
            border: 1px solid #cccccc;
            width: 420px;
            margin: 0 auto;
            padding: 15px;
        }
        h2 {
            margin-top: 0;
            color: #444;
        }
        input {
            width: 95%;
            padding: 8px;
            margin: 5px 0;
            border: 1px solid #bbbbbb;
            border-radius: 4px;
        }
        button {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border: none;
            background-color: #5C6AC4;
            color: #ffffff;
            border-radius: 4px;
            cursor: pointer;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
            font-size: 13px;
        }
        th, td {
            border: 1px solid #dddddd;
            padding: 4px;
            text-align: left;
        }
        a {
            color: #c00000;
            text-decoration: none;
            font-size: 12px;
        }
        .titulo-lista {
            margin-top: 15px;
            font-weight: bold;
            text-align: left;
            font-size: 13px;
        }
        .status-ok {
            color: #008000;
            font-weight: bold;
        }
    </style>
</head>
<body>

<div class="box">
    <h2>Gerenciador de Tarefas</h2>

    <form action="add_tarefa.php" method="POST">
        <input type="text" name="descricao" placeholder="Descrição da tarefa" required>
        <input type="date" name="prazo">
        <button type="submit">Adicionar tarefa</button>
    </form>

    <div class="titulo-lista">Tarefas pendentes</div>
    <table>
        <tr>
            <th>ID</th>
            <th>Descrição</th>
            <th>Prazo</th>
            <th>Ações</th>
        </tr>
        <?php
        $sqlPend = "SELECT * FROM tarefas WHERE concluida = 0 ORDER BY id DESC";
        $resPend = $conn->query($sqlPend);

        if ($resPend && $resPend->num_rows > 0) {
            while ($t = $resPend->fetch_assoc()) {
                echo "<tr>";
                echo "<td>".$t['id']."</td>";
                echo "<td>".$t['descricao']."</td>";
                echo "<td>".($t['prazo'] ?: "-")."</td>";
                echo "<td>
                        <a href='update_tarefa.php?id=".$t['id']."&acao=done'>Concluir</a><br>
                        <a href='delete_tarefa.php?id=".$t['id']."'>Excluir</a>
                      </td>";
                echo "</tr>";
            }
        }
        ?>
    </table>

    <div class="titulo-lista">Tarefas concluídas</div>
    <table>
        <tr>
            <th>ID</th>
            <th>Descrição</th>
            <th>Prazo</th>
            <th>Ações</th>
        </tr>
        <?php
        $sqlConc = "SELECT * FROM tarefas WHERE concluida = 1 ORDER BY id DESC";
        $resConc = $conn->query($sqlConc);

        if ($resConc && $resConc->num_rows > 0) {
            while ($t = $resConc->fetch_assoc()) {
                echo "<tr>";
                echo "<td>".$t['id']."</td>";
                echo "<td><span class='status-ok'>".$t['descricao']."</span></td>";
                echo "<td>".($t['prazo'] ?: "-")."</td>";
                echo "<td>
                        <a href='update_tarefa.php?id=".$t['id']."&acao=undo'>Reabrir</a><br>
                        <a href='delete_tarefa.php?id=".$t['id']."'>Excluir</a>
                      </td>";
                echo "</tr>";
            }
        }
        ?>
    </table>
</div>

</body>
</html>
