<?php
include "database.php";

if (!empty($_POST['descricao'])) {
    $descricao = $_POST['descricao'];
    $prazo     = !empty($_POST['prazo']) ? $_POST['prazo'] : null;

    if ($prazo) {
        $sql = "INSERT INTO tarefas (descricao, prazo, concluida)
                VALUES ('$descricao', '$prazo', 0)";
    } else {
        $sql = "INSERT INTO tarefas (descricao, concluida)
                VALUES ('$descricao', 0)";
    }

    $conn->query($sql);
}

header("Location: index.php");
exit;
?>