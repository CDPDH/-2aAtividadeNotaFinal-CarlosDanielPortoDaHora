<?php
include "database.php";

if (isset($_GET['id']) && isset($_GET['acao'])) {
    $id   = $_GET['id'];
    $acao = $_GET['acao'];

    if ($acao == "done") {
        $sql = "UPDATE tarefas SET concluida = 1 WHERE id = $id";
    } elseif ($acao == "undo") {
        $sql = "UPDATE tarefas SET concluida = 0 WHERE id = $id";
    }

    $conn->query($sql);
}

header("Location: index.php");
exit;
?>